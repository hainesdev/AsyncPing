#ifndef AsyncPing_h
#define AsyncPing_h

#define US_ROUNDTRIP_CM 57 
#define MAX_SENSOR_DISTANCE 500 // Maximum sensor distance can be as high as 500cm, no reason to wait for ping longer than sound takes to travel this distance and back.
#define MAX_SENSOR_DELAY 18000  // Maximum uS it takes for sensor to start the ping (SRF06 is the highest measured, just under 18ms).

#if defined(ARDUINO) && ARDUINO >= 100
	#include <Arduino.h>
#else
	#include <WProgram.h>
	#include <pins_arduino.h>
#endif

class AsyncPing
{
    	//Config Vars
        uint8_t _triggerBit;
	uint8_t _echoBit;
	volatile uint8_t *_triggerOutput;
	volatile uint8_t *_triggerMode;
	volatile uint8_t *_echoInput;
        unsigned long TimerP; //main
        // Loop Timing
        unsigned long Distance;
        unsigned long x;
        unsigned long cur_cycle_time, end_cycle_time, tot_cycle_time, max_cycle_time, avg_cycle_time;
        // functions
        void check();
        bool sendPing();
  public:
  unsigned int _maxEchoTime;
  unsigned long _max_time;
  unsigned long measure_echo();
  AsyncPing();
  unsigned long distance(int Accuracy);
};

#endif
