#include "AsyncPing.h"
AsyncPing::AsyncPing()
{
     //Initialize
        _triggerBit = digitalPinToBitMask(TRIGGER_PIN); // Get the port register bitmask for the trigger pin.
	_echoBit = digitalPinToBitMask(ECHO_PIN);       // Get the port register bitmask for the echo pin.
	_triggerOutput = portOutputRegister(digitalPinToPort(TRIGGER_PIN)); // Get the output port register for the trigger pin.
	_echoInput = portInputRegister(digitalPinToPort(ECHO_PIN));         // Get the input port register for the echo pin.
	_triggerMode = (uint8_t *) portModeRegister(digitalPinToPort(TRIGGER_PIN)); // Get the port mode register for the trigger pin.
	_maxEchoTime = min(MAX_DISTANCE, MAX_SENSOR_DISTANCE) * US_ROUNDTRIP_CM + (US_ROUNDTRIP_CM / 2); // Calculate the maximum distance in uS.
	*_triggerMode |= _triggerBit; // Set trigger pin to output.
        TimerP = micros();

   };
unsigned long AsyncPing::distance(int Accuracy)
{
  for(int i; i<Accuracy; i++)
  {
    check();
  }
  return Distance;
}
void AsyncPing::check()
{
   
     if (cur_cycle_time-TimerP < x)
      {
        *_triggerOutput |= _triggerBit;  // Set trigger pin high, this tells the sensor to send out a ping.
      }else{
        *_triggerOutput &= ~_triggerBit; // Set trigger pin back to low.
        if(sendPing())
        {
        
        Distance += measure_echo();
        Distance >>= 1;
        }
        TimerP = micros();
      }  

   end_cycle_time = micros();
   tot_cycle_time = end_cycle_time - cur_cycle_time;

   if(max_cycle_time<tot_cycle_time)
   {
     max_cycle_time += tot_cycle_time;
     max_cycle_time >>= 1;
   }
   
   x = max_cycle_time;
   cur_cycle_time = micros(); //set cur time before next iteration as to include the timing operations in the time calculation
   
};
bool AsyncPing::sendPing()
{
        _max_time =  micros() + MAX_SENSOR_DELAY;                  // Set a timeout for the ping to trigger.
      	while (*_echoInput & _echoBit && micros() <= _max_time) {} // Wait for echo pin to clear.
      	while (!(*_echoInput & _echoBit))                          // Wait for ping to start.
      		if (micros() > _max_time)
                   return 0;                // Something went wrong, abort.
      	_max_time = micros() + _maxEchoTime; // Ping started, set the timeout.
        return 1;  
}
unsigned long AsyncPing::measure_echo(){
  while (*_echoInput & _echoBit)                      // Wait for the ping echo.
    if (micros() > _max_time) return 0;       // Stop the loop and return NO_ECHO (false) if we're beyond the set maximum distance.
  unsigned long uS = (micros() - (_max_time - _maxEchoTime)); // Calculate ping time, 5uS of overhead.
  return uS;
}